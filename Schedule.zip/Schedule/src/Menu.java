public class Menu { //메뉴

	// 메뉴 출력
	public static void menu() {
		System.out.println("");
		System.out.println("-----------------------*********일정 관리 프로그램*********------------------------");
		System.out.println("1. 일정 등록");
		System.out.println("2. 일정 삭제");
		System.out.println("3. 전체 일정 보여주기");
		System.out.println("4. 일정 수정");
		System.out.println("5. 일정 검색");
		System.out.println("6. 파일로 저장하기");
		System.out.println("7. 파일 읽어들이기");
		System.out.println("8. 프로그램 종료");
		System.out.println("---------------------------------------------------------------------------");
		System.out.println("원하시는 프로그램 번호를 입력해주세요 : ");
	}
}